import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            HStack{
                Image(systemName: "book.pages.fill")
                .imageScale(.large)
                .foregroundColor(.accentColor)
                Text("LucaP")
                Spacer()
            }
            .font(.title2).bold()
            EntryTestView()
        }
    }
}
