import SwiftUI

struct ChartOfAccountsView: View {
    var accounts = ChartOfAccounts().accounts
    var accountCategories = AccountCategories().accountCategories
    
    var body: some View {
        VStack{
            List(accountCategories){ category in 
                HStack{
                    Text(category.id,format: .number.grouping(.never))
                    Text(category.name)
                }
            }
            
            List{
                ForEach(accounts){account in 
                    HStack{
                        Text(account.accountNumber)
                        Text(account.accountName)
                        Text("\(account.accountCategory)")
                        Text(accountCatName(id: account.accountCategory))
                    }    
                }
            }
        }
    }
    
    func accountCatName(id:Int)->String{
        if let index = accountCategories.firstIndex(where:{$0.id == id}){
            return accountCategories[index].name
        } else {
            return "not found"
        }
    }
}

#Preview {
    ChartOfAccountsView()
}
