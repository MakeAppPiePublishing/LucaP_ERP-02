import Foundation

var globalJournalEntryID = 0

class JournalEntry:Identifiable{
    var id:Int
    var date:Date
    var account:String
    var description:String
    var amount:Double
    var creditDebit:CreditDebit
    
   
    init( account:String,amount:Double,creditDebit:CreditDebit){
        id = globalJournalEntryID
        globalJournalEntryID += 1
        self.date = Date()
        self.account = account
        let coa = ChartOfAccounts().accounts
        if let accountInfo = coa.first(where:{$0.accountNumber == account}){
                self.description = accountInfo.accountName
            }else {
                self.description = "Account not found"
            }
        self.amount = amount
        self.creditDebit = creditDebit
    }
    
    func numAmount()->Double{
        return amount * creditDebit.rawValue
    }
    
    
}

var testEntries = [
    JournalEntry(account:"321000", amount: 1000, creditDebit: .credit),
    JournalEntry(account:"111000", amount: 1000, creditDebit: .debit),
    JournalEntry(account:"131100", amount: 300, creditDebit: .debit),
    JournalEntry(account:"111000", amount: 300, creditDebit: .credit),
    JournalEntry(account:"131100", amount: 100, creditDebit: .debit),
    JournalEntry(account:"211000", amount: 100, creditDebit: .credit),
    JournalEntry(account:"621000", amount: 300, creditDebit: .debit),
    JournalEntry(account:"111000", amount: 300, creditDebit: .credit),
    JournalEntry(account:"652100", amount: 200, creditDebit: .debit),
    JournalEntry(account:"111000", amount: 200, creditDebit: .credit),
    JournalEntry(account:"111000", amount: 5000, creditDebit: .debit),
    JournalEntry(account:"411000", amount: 5000, creditDebit: .credit),
    JournalEntry(account:"511000", amount: 400, creditDebit: .credit)
]
