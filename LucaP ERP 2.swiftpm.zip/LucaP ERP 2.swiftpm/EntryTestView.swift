import SwiftUI


struct EntryTestView: View {
    var journalEntries:[JournalEntry] = testEntries
    var body: some View {
        List(journalEntries){entry in
            HStack{
                Text(entry.id,format:.number)
                Text(entry.date,format:.dateTime)
                HStack{
                    Text(entry.account)
                    Text(entry.description)
                    Spacer()
                }
                .frame(width:300)
                if entry.creditDebit == .debit{
                    Text(entry.amount,format: .currency(code: "usd")).frame(minWidth:100)
                } else {
                    Text(" ").frame(minWidth:100)
                    Text(entry.amount,format: .currency(code: "usd")).frame(minWidth:100)
                }
            }    
        }
    }
}

#Preview {
    EntryTestView()
}
